
# **README — Arabic–German Legal Dataset (v1.0)**  
### **Bilingual Dataset: Arabic ↔ German**  
### **Release Date: March 2026**

---

## **1. Overview**
This dataset contains **1016 professionally curated bilingual legal sentences (Arabic–German)**.  
The content has been cleaned, standardized, and translated with high legal accuracy.

The dataset covers a broad range of legal domains, including:

- Civil contracts  
- Real estate agreements  
- Legal notices  
- Court pleadings  
- Guarantees and surety contracts  
- Personal status documents  
- Social security cases  
- Constitutional texts  
- Administrative forms  
- Legal templates and models  
- Marriage, divorce, inheritance, and property division  
- Investment laws  
- Vehicle and property usage agreements  

This dataset is suitable for training:

- Legal translation models  
- Legal text understanding models  
- Contract generation systems  
- Document analysis tools  
- Legal chatbots  
- Bilingual LLMs (Arabic–German)  

---

## **2. Dataset Structure**

Each entry in the dataset is stored in CSV format with the following columns:

| Column | Description |
|--------|-------------|
| **file_id** | Identifier for the document or legal category (e.g., `service_inclusion`, `constitutional_declaration`) |
| **id** | Sentence index within the file, starting from 1 |
| **source_ar** | Arabic legal text |
| **target_de** | German legal translation |
| **domain** | Domain label (always `legal`) |

Example row:

```
constitutional_declaration,4,"دين الدولة هو الإسلام مع احترام حرية غير المسلمين.","Die Religion des Staates ist der Islam, wobei die Religionsfreiheit für Nichtmuslime gewährleistet wird.",legal
```

---

## **3. Encoding**
- **UTF‑8 (no BOM)**  
- Fully compatible with major ML frameworks (PyTorch, TensorFlow, HuggingFace)

---

## **4. Data Quality Notes**

The dataset adheres to strict quality standards:

- Accurate legal translation  
- No spelling or grammatical errors  
- No duplicate entries  
- No empty rows  
- Unified punctuation and formatting  
- Consistent `file_id` naming  
- Consistent domain labeling (`legal`)  
- Professional legal phrasing suitable for training  

---

## **5. Metadata**

```
Dataset Name: Arabic-German Legal Dataset
Version: 1.0
Languages: Arabic (ar), German (de)
Total Sentences: 1016
Domain: Legal / Judicial / Administrative
Format: CSV (UTF-8)
Creator: Tahseen
Creation Date: March 2026
License: Private – Research and Model Training Only
Files Included: dataset.csv + README
```

---

## **6. Legal Text Categories Included**

- Sale contracts  
- Partition and co-ownership agreements  
- Mahayaa (rotational usage) contracts  
- Surety and guarantee contracts  
- Legal notices and warnings  
- Court claims and petitions  
- Power of attorney templates  
- Marriage and divorce forms  
- Death registration and inheritance documents  
- Investment law articles  
- Constitutional declaration (2025)  
- Social security and insurance claims  
- Vehicle usage agreements  
- Administrative legal forms  

---

## **7. Intended Use Cases**

- Training bilingual legal translation models  
- Fine-tuning LLMs for legal reasoning  
- Named Entity Recognition (NER) in legal texts  
- Contract summarization and generation  
- Legal chatbots and advisory systems  
- Automated document classification  
- Government and administrative AI tools  

---

## **8. Important Notes**

- All texts are generalized legal templates with no real personal data.  
- Users should split the dataset into train/dev/test before training.  
- A tokenizer supporting both Arabic and German (e.g., SentencePiece, BPE) is recommended.  
- The dataset is not intended for public redistribution without permission.  

---

## **9. Sample Entry**

```
service_inclusion,1,"دعوى ضم خدمات...","Klage auf Einbeziehung...",legal
```

---

## **10. License**

This dataset is **private** and intended for:

- Research  
- Model training  
- Internal development  

Commercial redistribution or resale is not permitted without explicit authorization.

---

## **11. Changelog**

**v1.0 — March 2026**
- Added 1016 bilingual legal sentences  
- Standardized formatting  
- Added German translations  
- Cleaned and validated all entries  
- Added README and metadata  

---

## **12. Final Note**

This dataset represents one of the most comprehensive and rare **Arabic–German legal corpora** available.  
It provides a strong foundation for building advanced bilingual legal AI systems.
